<html>
<head>
   <meta charset="utf8" />
   <script type="text/javascript" src="jquery.min.js"></script>
</head>
<body>
<h1>Alineaciones</h1>
<p><a href="javascript:busca('ATH')">Athletic de Bilbao</a>&nbsp;&nbsp;&nbsp;<a href="javascript:busca('VIL')">Villarreal</a></p>
<div id="alineacion">
</div>
</body>
</html>
   <script type="text/javascript">
   	function busca(id)
   	{
   		$('#alineacion').load('equipo.php', {'equipo': id });
   	}
   </script>
