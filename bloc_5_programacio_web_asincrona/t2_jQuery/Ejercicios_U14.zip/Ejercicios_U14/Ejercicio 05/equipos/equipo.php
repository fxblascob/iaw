<?php
if (isset($_REQUEST['equipo']))
{
	if ($_REQUEST['equipo'] == 'ATH')
	{
?>
	<ol>
		<li>Iraizoz</li>
		<li>Iraola</li>
		<li>Laporte</li>
		<li>Balenziaga</li>
		<li>San José</li>
		<li>Beñat</li>
		<li>De Marcos</li>
		<li>Gurpegui</li>
		<li>Iturraspe</li>
		<li>Aduriz</li>
		<li>Muniain</li>	
	</ol>
<?php
	} else if ($_REQUEST['equipo'] == 'VIL') {
?>
	<ol>
		<li>Asenjo</li>
		<li>Dorado</li>
		<li>Costa</li>
		<li>Musacchio</li>
		<li>Víctor Ruiz</li>
		<li>Bruno</li>
		<li>Cheryshev</li>
		<li>Jonathan Dos Santos</li>
		<li>Pina</li>
		<li>Giovanni Dos Santos</li>
		<li>Uche</li>
	</ol>
<?php 
	}
}
?>
