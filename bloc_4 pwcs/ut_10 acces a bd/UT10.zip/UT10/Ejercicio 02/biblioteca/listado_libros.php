﻿<html>
<head>
	<meta charset="utf8">
	<title>Ejercicios de PHP</title>
</head>
<body>
	<h1>Listado de libros</h1>
	<?php
		$bd = @mysqli_connect("localhost", "root", "", "biblioteca", 3307);
		mysqli_set_charset($bd, "utf8");
		if (mysqli_connect_errno() != 0)
		{
			echo '<p>Error: ' . mysqli_connect_error() . '</p>';
		} else {
			$comando = "SELECT codigo, titulo, autor FROM libro";
			$resultado = mysqli_query($bd, $comando);
			if (mysqli_errno($bd) != 0)
			{
				echo 'Error: ' . mysqli_error($bd);
			}
			else if (mysqli_num_rows($resultado) > 0)
			{
				echo '<ul>';
				while ($fila = mysqli_fetch_assoc($resultado))
				{
					$codigo = $fila['codigo'];
					$titulo = $fila['titulo'];
					$autor = $fila['autor'];
					echo "<li>$titulo ($autor) [<a href=\"info_libro.php?id=$codigo\">Ver información</a>]</li>";
				}
				echo '</ul>';
			} else {
				echo '<p>No se han encontrado registros que mostrar.</p>';
			}
			@mysqli_free_result($resultado);
			mysqli_close($bd);
		}
	?>
</body>
</html>