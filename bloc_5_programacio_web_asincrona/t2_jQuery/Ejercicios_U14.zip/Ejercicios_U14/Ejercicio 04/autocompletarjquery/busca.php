<?php
   if (isset($_REQUEST['texto']))
   {
      $texto = strtolower($_REQUEST['texto']);
      $datos = file('peliculas.txt');
      echo '<ul>';
      foreach ($datos as $pelicula)
      {
         $pelilow = strtolower($pelicula);
         if (strpos(' ' . $pelilow, $texto))
         	echo "<li>$pelicula</li>";  
      }
      echo '</ul>';
   }
?>